#!/bin/bash

echo "🔧 Iniciando setup do Mediaflow Suite..."

# Atualiza pacotes e instala Docker + Compose
sudo apt update && sudo apt install -y docker.io docker-compose unzip

# Inicia os containers
docker-compose up -d --build

echo "✅ Containers iniciados com sucesso!"
echo "🔗 Painel Web: http://$(curl -s ifconfig.me):8080"
echo "🔗 Proxy: http://$(curl -s ifconfig.me):10000"
echo "🔗 AIOStreams: http://$(curl -s ifconfig.me):3000"