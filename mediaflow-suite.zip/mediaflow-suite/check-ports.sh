#!/bin/bash

echo "🔍 Verificando escuta nas portas 3000, 8080 e 10000..."
sudo ss -tuln | grep -E '3000|8080|10000'