\# Mediaflow Suite



Este pacote contém:



\- Proxy com autenticação via senha

\- Painel Web leve

\- AIOStreams integrado

\- Scripts de setup e verificação



\## Como usar



```bash

unzip mediaflow-suite.zip

cd mediaflow-suite

bash setup.sh

bash check-ports.sh

